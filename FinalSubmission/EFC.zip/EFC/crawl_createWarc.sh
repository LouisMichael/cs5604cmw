#!/bin/bash
python .\FocusedCrawler.py b $1 $2

python3 .\generateWarc.py $1